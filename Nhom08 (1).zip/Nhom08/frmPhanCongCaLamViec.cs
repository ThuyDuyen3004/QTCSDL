﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; //buoc 0

namespace Nhom08
{
    public partial class frmPhanCongCaLamViec : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";
        public frmPhanCongCaLamViec()
        {
            InitializeComponent();
        }

        private void frmPhanCongCaLamViec_Load(object sender, EventArgs e)
        {

            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from PhanCongCaLamViec";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "PhanCongCaLamViec");

            dataGridViewPhanCongCaLamViec.DataSource = ds.Tables["PhanCongCaLamViec"];

            con.Close(); //buoc 3
        }

        private void btnLuuPhanCongCaLam_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaNhanVien = textMaNhanVien.Text;
            string sMaPhanCong = textMaPhanCong.Text;
            string sTenCa = textTenCaLam.Text;
            string sNgayLam = dateTimePickerNgayLam.Value.ToString("yyyy-MM-dd");
            string sGioVaoCa = dateTimePickerGioVaoCa.Value.ToString("HH:mm:ss");
            string sGioKetCa = dateTimePickerGioKetCa.Value.ToString("HH:mm:ss");

            // kiem tra du lieu

            if (dateTimePickerNgayLam.Value.Date < DateTime.Now.Date)
            {
                MessageBox.Show("Ngày làm việc không được là ngày trong quá khứ!", "Thông báo");
                con.Close();
                return;
            }


            string queryCheckMaNV = "select count (*) from NhanVien where MaNV = @MaNV";
            SqlCommand cmdCheckMaNV = new SqlCommand(queryCheckMaNV, con);
            cmdCheckMaNV.Parameters.AddWithValue("@MaNV", sMaNhanVien);

            int countMaNV = (int)cmdCheckMaNV.ExecuteScalar();
            if (countMaNV == 0)
            {
                MessageBox.Show("Mã nhân viên không tồn tại trong hệ thống!", "Thông báo");
                con.Close();
                return;
            }

            if (sMaPhanCong.Length != 7)
            {
                MessageBox.Show("Mã phân công phải đủ 7 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            string sQuery = "insert into PhanCongCaLamViec values (@MaPhanCong,@MaNV,@NgayThangNamLamViec,@TenCa, @Thoigianvaoca, @Thoigianketca) ";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaPhanCong", sMaPhanCong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@TenCa", sTenCa);
            cmd.Parameters.AddWithValue("@NgayThangNamLamViec", sNgayLam);
            cmd.Parameters.AddWithValue("@Thoigianvaoca", sGioVaoCa);
            cmd.Parameters.AddWithValue("@Thoigianketca", sGioKetCa);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!");

                string reloadQuery = "select * from PhanCongCaLamViec";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "PhanCongCaLamViec");
                dataGridViewPhanCongCaLamViec.DataSource = ds.Tables["PhanCongCaLamViec"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show($"Xảy ra lỗi trong quá trình thêm mới: {ex.Message}", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();

        }

        private void dataGridViewPhanCongCaLamViec_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textMaPhanCong.Text = dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["MaPhanCong"].Value.ToString();
            textMaNhanVien.Text = dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["MaNV"].Value.ToString();
            dateTimePickerNgayLam.Value = Convert.ToDateTime(dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["NgayThangNamLamViec"].Value.ToString());

            textTenCaLam.Text = dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["TenCa"].Value.ToString();

            dateTimePickerGioVaoCa.Value = DateTime.Today + TimeSpan.Parse(dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["Thoigianvaoca"].Value.ToString());
            dateTimePickerGioKetCa.Value = DateTime.Today + TimeSpan.Parse(dataGridViewPhanCongCaLamViec.Rows[e.RowIndex].Cells["Thoigianketca"].Value.ToString());

            textMaPhanCong.Enabled = false;


        }

        private void btnSuaPhanCongCaLam_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaNhanVien = textMaNhanVien.Text;
            string sMaPhanCong = textMaPhanCong.Text;
            string sTenCa = textTenCaLam.Text;
            string sNgayLam = dateTimePickerNgayLam.Value.ToString("yyyy-MM-dd");
            string sGioVaoCa = dateTimePickerGioVaoCa.Value.ToString("HH:mm:ss");
            string sGioKetCa = dateTimePickerGioKetCa.Value.ToString("HH:mm:ss");

            // kiem tra du lieu

            if (dateTimePickerNgayLam.Value.Date < DateTime.Now.Date)
            {
                MessageBox.Show("Ngày làm việc không được là ngày trong quá khứ!", "Thông báo");
                con.Close();
                return;
            }


            string queryCheckMaNV = "select count (*) from NhanVien where MaNV = @MaNV";
            SqlCommand cmdCheckMaNV = new SqlCommand(queryCheckMaNV, con);
            cmdCheckMaNV.Parameters.AddWithValue("@MaNV", sMaNhanVien);

            int countMaNV = (int)cmdCheckMaNV.ExecuteScalar();
            if (countMaNV == 0)
            {
                MessageBox.Show("Mã nhân viên không tồn tại trong hệ thống!", "Thông báo");
                con.Close();
                return;
            }

            if (sMaPhanCong.Length != 7)
            {
                MessageBox.Show("Mã phân công phải đủ 7 ký tự!", "Thông báo");
                con.Close();
                return;
            }

            string sQuery = "update PhanCongCaLamViec set MaNV = @MaNV, TenCa = @TenCa, " +
                "NgayThangNamLamViec = @NgayThangNamLamViec, Thoigianvaoca = @Thoigianvaoca, " +
                "Thoigianketca = @Thoigianketca " +
                "where MaPhanCong = @MaPhanCong";

            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaPhanCong", sMaPhanCong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@TenCa", sTenCa);
            cmd.Parameters.AddWithValue("@NgayThangNamLamViec", sNgayLam);
            cmd.Parameters.AddWithValue("@Thoigianvaoca", sGioVaoCa);
            cmd.Parameters.AddWithValue("@Thoigianketca", sGioKetCa);
            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!");

                string reloadQuery = "select * from PhanCongCaLamViec";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "PhanCongCaLamViec");
                dataGridViewPhanCongCaLamViec.DataSource = ds.Tables["PhanCongCaLamViec"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật!", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnXoaPhanCongCaLam_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }
                //buoc 2:
                // lay gia tri
                string sMaPhanCong = textMaPhanCong.Text;
                string sQuery = "delete PhanCongCaLamViec where MaPhanCong = @MaPhanCong";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaPhanCong", sMaPhanCong);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");

                    string reloadQuery = "select * from PhanCongCaLamViec";
                    SqlDataAdapter da = new SqlDataAdapter(reloadQuery, sCon);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewPhanCongCaLamViec.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa: " + ex.Message);
                }
                con.Close();
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
