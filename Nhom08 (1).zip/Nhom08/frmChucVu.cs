﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; //buoc 0

namespace Nhom08
{
    public partial class frmChucVu : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";

        public frmChucVu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void frmChucVu_Load(object sender, EventArgs e)
        {
            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from ChucVu";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "ChucVu");

            dataGridViewChucVu.DataSource = ds.Tables["ChucVu"];

            con.Close(); //buoc 3
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            string sMaChucVu = textMaChucVu.Text;
            string sChucVu = textChucVu.Text;
            string sLuongTheoGio = textLuongTheoGio.Text;

            string sQuery = "insert into ChucVu values (@MaChucVu, @ChucVu, @LuongTheoGio) ";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);
            cmd.Parameters.AddWithValue("@ChucVu", sChucVu);
            cmd.Parameters.AddWithValue("@LuongTheoGio", sLuongTheoGio);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!");
                string reloadQuery = "select * from ChucVu";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "ChucVu");
                dataGridViewChucVu.DataSource = ds.Tables["ChucVu"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm mới!", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaChucVu = textMaChucVu.Text;
            string sChucVu = textChucVu.Text;
            string sLuongTheoGio = textLuongTheoGio.Text;

            string sQuery = "update ChucVu set ChucVu = @ChucVu, LuongTheoGio = @LuongTheoGio where MaChucVu = @MaChucVu";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);
            cmd.Parameters.AddWithValue("@ChucVu", sChucVu);
            cmd.Parameters.AddWithValue("@LuongTheoGio", sLuongTheoGio);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!");
                string reloadQuery = "select * from ChucVu";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "ChucVu");
                dataGridViewChucVu.DataSource = ds.Tables["ChucVu"];

            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật! ", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void dataGridViewChucVu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewChucVu_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            textMaChucVu.Text = dataGridViewChucVu.Rows[e.RowIndex].Cells["MaChucVu"].Value.ToString();
            textChucVu.Text = dataGridViewChucVu.Rows[e.RowIndex].Cells["ChucVu"].Value.ToString();
            textLuongTheoGio.Text = dataGridViewChucVu.Rows[e.RowIndex].Cells["LuongTheoGio"].Value.ToString();
            textMaChucVu.Enabled = false;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }

                // buoc 2: chuẩn bị dữ liệu
                string sMaChucVu = textMaChucVu.Text;
                string sQuery = "delete ChucVu where MaChucVu = @MaChucVu";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");

                    string reloadQuery = "select * from ChucVu";
                    SqlDataAdapter da = new SqlDataAdapter(reloadQuery, sCon);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewChucVu.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa: " + ex.Message);
                }
                con.Close();

            }

         }
    }
}
