﻿namespace Nhom08
{
    partial class frmUngLuong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textMaUngLuong = new TextBox();
            label2 = new Label();
            textMaNhanVien = new TextBox();
            label3 = new Label();
            dateTimePickerNgayUngLuong = new DateTimePicker();
            label4 = new Label();
            textSoTienUng = new TextBox();
            btnLuuUngLuong = new Button();
            dataGridViewUngLuong = new DataGridView();
            btnSuaUngLuong = new Button();
            btnXoaUngLuong = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUngLuong).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(30, 37);
            label1.Name = "label1";
            label1.Size = new Size(145, 25);
            label1.TabIndex = 0;
            label1.Text = "Mã ứng lương";
            // 
            // textMaUngLuong
            // 
            textMaUngLuong.BorderStyle = BorderStyle.FixedSingle;
            textMaUngLuong.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaUngLuong.Location = new Point(200, 37);
            textMaUngLuong.Name = "textMaUngLuong";
            textMaUngLuong.Size = new Size(162, 33);
            textMaUngLuong.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(422, 40);
            label2.Name = "label2";
            label2.Size = new Size(142, 25);
            label2.TabIndex = 2;
            label2.Text = "Mã nhân viên";
            // 
            // textMaNhanVien
            // 
            textMaNhanVien.BorderStyle = BorderStyle.FixedSingle;
            textMaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaNhanVien.Location = new Point(588, 37);
            textMaNhanVien.Name = "textMaNhanVien";
            textMaNhanVien.Size = new Size(178, 33);
            textMaNhanVien.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(30, 96);
            label3.Name = "label3";
            label3.Size = new Size(102, 25);
            label3.TabIndex = 4;
            label3.Text = "Ngày ứng";
            // 
            // dateTimePickerNgayUngLuong
            // 
            dateTimePickerNgayUngLuong.Format = DateTimePickerFormat.Short;
            dateTimePickerNgayUngLuong.Location = new Point(200, 96);
            dateTimePickerNgayUngLuong.Name = "dateTimePickerNgayUngLuong";
            dateTimePickerNgayUngLuong.Size = new Size(162, 31);
            dateTimePickerNgayUngLuong.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(422, 102);
            label4.Name = "label4";
            label4.Size = new Size(124, 25);
            label4.TabIndex = 6;
            label4.Text = "Số tiền ứng ";
            // 
            // textSoTienUng
            // 
            textSoTienUng.BorderStyle = BorderStyle.FixedSingle;
            textSoTienUng.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textSoTienUng.Location = new Point(588, 96);
            textSoTienUng.Name = "textSoTienUng";
            textSoTienUng.Size = new Size(178, 33);
            textSoTienUng.TabIndex = 7;
            // 
            // btnLuuUngLuong
            // 
            btnLuuUngLuong.BackColor = Color.Lime;
            btnLuuUngLuong.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuuUngLuong.Location = new Point(200, 154);
            btnLuuUngLuong.Name = "btnLuuUngLuong";
            btnLuuUngLuong.Size = new Size(112, 34);
            btnLuuUngLuong.TabIndex = 8;
            btnLuuUngLuong.Text = "Lưu";
            btnLuuUngLuong.UseVisualStyleBackColor = false;
            btnLuuUngLuong.Click += btnLuuUngLuong_Click;
            // 
            // dataGridViewUngLuong
            // 
            dataGridViewUngLuong.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewUngLuong.Location = new Point(30, 211);
            dataGridViewUngLuong.Name = "dataGridViewUngLuong";
            dataGridViewUngLuong.RowHeadersWidth = 62;
            dataGridViewUngLuong.Size = new Size(736, 227);
            dataGridViewUngLuong.TabIndex = 9;
            dataGridViewUngLuong.CellClick += dataGridViewUngLuong_CellClick;
            // 
            // btnSuaUngLuong
            // 
            btnSuaUngLuong.BackColor = Color.Yellow;
            btnSuaUngLuong.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSuaUngLuong.Location = new Point(344, 154);
            btnSuaUngLuong.Name = "btnSuaUngLuong";
            btnSuaUngLuong.Size = new Size(112, 34);
            btnSuaUngLuong.TabIndex = 10;
            btnSuaUngLuong.Text = "Sửa";
            btnSuaUngLuong.UseVisualStyleBackColor = false;
            btnSuaUngLuong.Click += btnSuaUngLuong_Click;
            // 
            // btnXoaUngLuong
            // 
            btnXoaUngLuong.BackColor = Color.Red;
            btnXoaUngLuong.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoaUngLuong.Location = new Point(497, 154);
            btnXoaUngLuong.Name = "btnXoaUngLuong";
            btnXoaUngLuong.Size = new Size(112, 34);
            btnXoaUngLuong.TabIndex = 11;
            btnXoaUngLuong.Text = "Xóa";
            btnXoaUngLuong.UseVisualStyleBackColor = false;
            btnXoaUngLuong.Click += btnXoaUngLuong_Click;
            // 
            // frmUngLuong
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(800, 450);
            Controls.Add(btnXoaUngLuong);
            Controls.Add(btnSuaUngLuong);
            Controls.Add(dataGridViewUngLuong);
            Controls.Add(btnLuuUngLuong);
            Controls.Add(textSoTienUng);
            Controls.Add(label4);
            Controls.Add(dateTimePickerNgayUngLuong);
            Controls.Add(label3);
            Controls.Add(textMaNhanVien);
            Controls.Add(label2);
            Controls.Add(textMaUngLuong);
            Controls.Add(label1);
            Name = "frmUngLuong";
            Text = "frmUngLuong";
            Load += frmUngLuong_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewUngLuong).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textMaUngLuong;
        private Label label2;
        private TextBox textMaNhanVien;
        private Label label3;
        private DateTimePicker dateTimePickerNgayUngLuong;
        private Label label4;
        private TextBox textSoTienUng;
        private Button btnLuuUngLuong;
        private DataGridView dataGridViewUngLuong;
        private Button btnSuaUngLuong;
        private Button btnXoaUngLuong;
    }
}