﻿namespace Nhom08
{
    partial class frmNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MaNV = new Label();
            textMaNhanVien = new TextBox();
            HoVaTen = new Label();
            textHoVaTen = new TextBox();
            GioiTinh = new Label();
            btnrbNam = new RadioButton();
            btnrbNu = new RadioButton();
            label1 = new Label();
            dateTimePickerNgaysinh = new DateTimePicker();
            label2 = new Label();
            textMaChucVu = new TextBox();
            label3 = new Label();
            textSoDienThoai = new TextBox();
            label4 = new Label();
            textDiaChi = new TextBox();
            dataGridViewNhanVien = new DataGridView();
            btnLuuNhanVien = new Button();
            btnXoaNhanVien = new Button();
            btnSuaNhanVIen = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewNhanVien).BeginInit();
            SuspendLayout();
            // 
            // MaNV
            // 
            MaNV.AutoSize = true;
            MaNV.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MaNV.Location = new Point(48, 38);
            MaNV.Name = "MaNV";
            MaNV.Size = new Size(142, 25);
            MaNV.TabIndex = 0;
            MaNV.Text = "Mã nhân viên";
            MaNV.Click += MaNV_Click;
            // 
            // textMaNhanVien
            // 
            textMaNhanVien.BorderStyle = BorderStyle.FixedSingle;
            textMaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaNhanVien.Location = new Point(226, 35);
            textMaNhanVien.Name = "textMaNhanVien";
            textMaNhanVien.Size = new Size(193, 33);
            textMaNhanVien.TabIndex = 1;
            textMaNhanVien.TextChanged += textMaNhanVien_TextChanged;
            // 
            // HoVaTen
            // 
            HoVaTen.AutoSize = true;
            HoVaTen.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            HoVaTen.Location = new Point(48, 86);
            HoVaTen.Name = "HoVaTen";
            HoVaTen.Size = new Size(104, 25);
            HoVaTen.TabIndex = 2;
            HoVaTen.Text = "Họ và tên";
            // 
            // textHoVaTen
            // 
            textHoVaTen.BorderStyle = BorderStyle.FixedSingle;
            textHoVaTen.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textHoVaTen.Location = new Point(226, 76);
            textHoVaTen.Name = "textHoVaTen";
            textHoVaTen.Size = new Size(193, 33);
            textHoVaTen.TabIndex = 3;
            // 
            // GioiTinh
            // 
            GioiTinh.AutoSize = true;
            GioiTinh.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GioiTinh.Location = new Point(664, 93);
            GioiTinh.Name = "GioiTinh";
            GioiTinh.Size = new Size(96, 25);
            GioiTinh.TabIndex = 4;
            GioiTinh.Text = "Giới tính";
            // 
            // btnrbNam
            // 
            btnrbNam.AutoSize = true;
            btnrbNam.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnrbNam.Location = new Point(908, 86);
            btnrbNam.Name = "btnrbNam";
            btnrbNam.Size = new Size(82, 29);
            btnrbNam.TabIndex = 5;
            btnrbNam.TabStop = true;
            btnrbNam.Text = "Nam";
            btnrbNam.UseVisualStyleBackColor = true;
            // 
            // btnrbNu
            // 
            btnrbNu.AutoSize = true;
            btnrbNu.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnrbNu.Location = new Point(1068, 82);
            btnrbNu.Name = "btnrbNu";
            btnrbNu.Size = new Size(66, 29);
            btnrbNu.TabIndex = 6;
            btnrbNu.TabStop = true;
            btnrbNu.Text = "Nữ";
            btnrbNu.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(48, 136);
            label1.Name = "label1";
            label1.Size = new Size(105, 25);
            label1.TabIndex = 7;
            label1.Text = "Ngày sinh";
            label1.Click += label1_Click;
            // 
            // dateTimePickerNgaysinh
            // 
            dateTimePickerNgaysinh.Format = DateTimePickerFormat.Short;
            dateTimePickerNgaysinh.Location = new Point(226, 136);
            dateTimePickerNgaysinh.Name = "dateTimePickerNgaysinh";
            dateTimePickerNgaysinh.Size = new Size(193, 31);
            dateTimePickerNgaysinh.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(664, 40);
            label2.Name = "label2";
            label2.Size = new Size(124, 25);
            label2.TabIndex = 9;
            label2.Text = "Mã chức vụ";
            // 
            // textMaChucVu
            // 
            textMaChucVu.BorderStyle = BorderStyle.FixedSingle;
            textMaChucVu.Location = new Point(908, 32);
            textMaChucVu.Name = "textMaChucVu";
            textMaChucVu.Size = new Size(226, 31);
            textMaChucVu.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(664, 148);
            label3.Name = "label3";
            label3.Size = new Size(134, 25);
            label3.TabIndex = 11;
            label3.Text = "Số điện thoại";
            // 
            // textSoDienThoai
            // 
            textSoDienThoai.BorderStyle = BorderStyle.FixedSingle;
            textSoDienThoai.Location = new Point(908, 136);
            textSoDienThoai.Name = "textSoDienThoai";
            textSoDienThoai.Size = new Size(226, 31);
            textSoDienThoai.TabIndex = 12;
            textSoDienThoai.TextChanged += textSoDienThoai_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(48, 199);
            label4.Name = "label4";
            label4.Size = new Size(85, 25);
            label4.TabIndex = 13;
            label4.Text = "Địa chỉ ";
            // 
            // textDiaChi
            // 
            textDiaChi.BorderStyle = BorderStyle.FixedSingle;
            textDiaChi.Location = new Point(226, 188);
            textDiaChi.Name = "textDiaChi";
            textDiaChi.Size = new Size(193, 31);
            textDiaChi.TabIndex = 14;
            // 
            // dataGridViewNhanVien
            // 
            dataGridViewNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewNhanVien.Location = new Point(48, 252);
            dataGridViewNhanVien.Name = "dataGridViewNhanVien";
            dataGridViewNhanVien.RowHeadersWidth = 62;
            dataGridViewNhanVien.Size = new Size(1086, 199);
            dataGridViewNhanVien.TabIndex = 15;
            dataGridViewNhanVien.CellClick += dataGridViewNhanVien_CellClick;
            dataGridViewNhanVien.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnLuuNhanVien
            // 
            btnLuuNhanVien.BackColor = Color.Chartreuse;
            btnLuuNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuuNhanVien.Location = new Point(664, 194);
            btnLuuNhanVien.Name = "btnLuuNhanVien";
            btnLuuNhanVien.Size = new Size(112, 34);
            btnLuuNhanVien.TabIndex = 16;
            btnLuuNhanVien.Text = "Lưu";
            btnLuuNhanVien.UseVisualStyleBackColor = false;
            btnLuuNhanVien.Click += btnLuuNhanVien_Click;
            // 
            // btnXoaNhanVien
            // 
            btnXoaNhanVien.BackColor = Color.Red;
            btnXoaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoaNhanVien.Location = new Point(1022, 190);
            btnXoaNhanVien.Name = "btnXoaNhanVien";
            btnXoaNhanVien.Size = new Size(112, 34);
            btnXoaNhanVien.TabIndex = 17;
            btnXoaNhanVien.Text = "Xóa";
            btnXoaNhanVien.UseVisualStyleBackColor = false;
            btnXoaNhanVien.Click += btnXoaNhanVien_Click;
            // 
            // btnSuaNhanVIen
            // 
            btnSuaNhanVIen.BackColor = Color.Yellow;
            btnSuaNhanVIen.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSuaNhanVIen.Location = new Point(840, 190);
            btnSuaNhanVIen.Name = "btnSuaNhanVIen";
            btnSuaNhanVIen.Size = new Size(112, 34);
            btnSuaNhanVIen.TabIndex = 18;
            btnSuaNhanVIen.Text = "Sửa";
            btnSuaNhanVIen.UseVisualStyleBackColor = false;
            btnSuaNhanVIen.Click += btnSuaNhanVIen_Click;
            // 
            // frmNhanVien
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(1186, 550);
            Controls.Add(btnSuaNhanVIen);
            Controls.Add(btnXoaNhanVien);
            Controls.Add(btnLuuNhanVien);
            Controls.Add(dataGridViewNhanVien);
            Controls.Add(textDiaChi);
            Controls.Add(label4);
            Controls.Add(textSoDienThoai);
            Controls.Add(label3);
            Controls.Add(textMaChucVu);
            Controls.Add(label2);
            Controls.Add(dateTimePickerNgaysinh);
            Controls.Add(label1);
            Controls.Add(btnrbNu);
            Controls.Add(btnrbNam);
            Controls.Add(GioiTinh);
            Controls.Add(textHoVaTen);
            Controls.Add(HoVaTen);
            Controls.Add(textMaNhanVien);
            Controls.Add(MaNV);
            Name = "frmNhanVien";
            Text = "Nhân Viên";
            Load += frmNhanVien_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewNhanVien).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label MaNV;
        private TextBox textMaNhanVien;
        private Label HoVaTen;
        private TextBox textHoVaTen;
        private Label GioiTinh;
        private RadioButton btnrbNam;
        private RadioButton btnrbNu;
        private Label label1;
        private DateTimePicker dateTimePickerNgaysinh;
        private Label label2;
        private TextBox textMaChucVu;
        private Label label3;
        private TextBox textSoDienThoai;
        private Label label4;
        private TextBox textDiaChi;
        private DataGridView dataGridViewNhanVien;
        private Button btnLuuNhanVien;
        private Button btnXoaNhanVien;
        private Button btnSuaNhanVIen;
    }
}