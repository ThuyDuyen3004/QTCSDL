﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // buoc 0

namespace Nhom08
{
    public partial class frmUngLuong : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";

        public frmUngLuong()
        {
            InitializeComponent();
        }

        private void frmUngLuong_Load(object sender, EventArgs e)
        {
            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from UngLuong";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "UngLuong");

            dataGridViewUngLuong.DataSource = ds.Tables["UngLuong"];

            con.Close(); //buoc 3
        }

        private void dataGridViewUngLuong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textMaUngLuong.Text = dataGridViewUngLuong.Rows[e.RowIndex].Cells["MaUngLuong"].Value.ToString();
            textMaNhanVien.Text = dataGridViewUngLuong.Rows[e.RowIndex].Cells["MaNV"].Value.ToString();
            dateTimePickerNgayUngLuong.Value = Convert.ToDateTime(dataGridViewUngLuong.Rows[e.RowIndex].Cells["NgayUng"].Value.ToString());
            textSoTienUng.Text = dataGridViewUngLuong.Rows[e.RowIndex].Cells["SoTien"].Value.ToString();
            textMaUngLuong.Enabled = false;
        }

        private void btnLuuUngLuong_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            string sMaUngLuong = textMaUngLuong.Text;
            string sMaNV = textMaNhanVien.Text;
            string sSoTienUng = textSoTienUng.Text;
            string sNgayUng = dateTimePickerNgayUngLuong.Value.ToString("yyyy-MM-dd");

            string sQuery = "insert into UngLuong values (@MaUngLuong, @MaNV, @NgayUng, @SoTien) ";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaUngLuong", sMaUngLuong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNV);
            cmd.Parameters.AddWithValue("@NgayUng", sNgayUng);
            cmd.Parameters.AddWithValue("@SoTien", sSoTienUng);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm mới thành công!");
                string reloadQuery = "select * from UngLuong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "UngLuong");
                dataGridViewUngLuong.DataSource = ds.Tables["UngLuong"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm mới!", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnSuaUngLuong_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaUngLuong = textMaUngLuong.Text;
            string sMaNV = textMaNhanVien.Text;
            string sSoTienUng = textSoTienUng.Text;
            string sNgayUng = dateTimePickerNgayUngLuong.Value.ToString("yyyy-MM-dd");

            string sQuery = "update UngLuong set MaNV = @MaNV,NgayUng = @NgayUng, SoTien = @SoTien where  MaUngLuong = @MaUngLuong";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaUngLuong", sMaUngLuong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNV);
            cmd.Parameters.AddWithValue("@NgayUng", sNgayUng);
            cmd.Parameters.AddWithValue("@SoTien", sSoTienUng);


            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!");
                string reloadQuery = "select * from UngLuong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "UngLuong");
                dataGridViewUngLuong.DataSource = ds.Tables["UngLuong"];

            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật! ", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnXoaUngLuong_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }

                // buoc 2: chuẩn bị dữ liệu
                string sMaUngLuong = textMaUngLuong.Text;
                string sQuery = "delete UngLuong where MaUngLuong = @MaUngLuong";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaUngLuong", sMaUngLuong);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");

                    string reloadQuery = "select * from UngLuong";
                    SqlDataAdapter da = new SqlDataAdapter(reloadQuery, sCon);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewUngLuong.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa: " + ex.Message);
                }
                con.Close();

            }
        }
    }
}
