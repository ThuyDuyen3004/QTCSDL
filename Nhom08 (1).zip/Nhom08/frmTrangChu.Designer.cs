﻿namespace Nhom08
{
    partial class frmTrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            trangChủToolStripMenuItem = new ToolStripMenuItem();
            nhânViênToolStripMenuItem = new ToolStripMenuItem();
            phânToolStripMenuItem = new ToolStripMenuItem();
            chấmCôngToolStripMenuItem = new ToolStripMenuItem();
            lươngToolStripMenuItem = new ToolStripMenuItem();
            ứngLươngToolStripMenuItem = new ToolStripMenuItem();
            chứcVụToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = Color.FromArgb(255, 192, 128);
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { trangChủToolStripMenuItem, nhânViênToolStripMenuItem, phânToolStripMenuItem, chấmCôngToolStripMenuItem, lươngToolStripMenuItem, ứngLươngToolStripMenuItem, chứcVụToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(892, 33);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // trangChủToolStripMenuItem
            // 
            trangChủToolStripMenuItem.Name = "trangChủToolStripMenuItem";
            trangChủToolStripMenuItem.Size = new Size(104, 29);
            trangChủToolStripMenuItem.Text = "Trang chủ";
            // 
            // nhânViênToolStripMenuItem
            // 
            nhânViênToolStripMenuItem.Name = "nhânViênToolStripMenuItem";
            nhânViênToolStripMenuItem.Size = new Size(107, 29);
            nhânViênToolStripMenuItem.Text = "Nhân viên";
            nhânViênToolStripMenuItem.Click += nhânViênToolStripMenuItem_Click;
            // 
            // phânToolStripMenuItem
            // 
            phânToolStripMenuItem.Name = "phânToolStripMenuItem";
            phânToolStripMenuItem.Size = new Size(203, 29);
            phânToolStripMenuItem.Text = "Phân công ca làm việc";
            phânToolStripMenuItem.Click += phânToolStripMenuItem_Click;
            // 
            // chấmCôngToolStripMenuItem
            // 
            chấmCôngToolStripMenuItem.Name = "chấmCôngToolStripMenuItem";
            chấmCôngToolStripMenuItem.Size = new Size(119, 29);
            chấmCôngToolStripMenuItem.Text = "Chấm công";
            chấmCôngToolStripMenuItem.Click += chấmCôngToolStripMenuItem_Click;
            // 
            // lươngToolStripMenuItem
            // 
            lươngToolStripMenuItem.Name = "lươngToolStripMenuItem";
            lươngToolStripMenuItem.Size = new Size(79, 29);
            lươngToolStripMenuItem.Text = "Lương";
            lươngToolStripMenuItem.Click += lươngToolStripMenuItem_Click;
            // 
            // ứngLươngToolStripMenuItem
            // 
            ứngLươngToolStripMenuItem.Name = "ứngLươngToolStripMenuItem";
            ứngLươngToolStripMenuItem.Size = new Size(114, 29);
            ứngLươngToolStripMenuItem.Text = "Ứng lương";
            ứngLươngToolStripMenuItem.Click += ứngLươngToolStripMenuItem_Click;
            // 
            // chứcVụToolStripMenuItem
            // 
            chứcVụToolStripMenuItem.Name = "chứcVụToolStripMenuItem";
            chứcVụToolStripMenuItem.Size = new Size(92, 29);
            chứcVụToolStripMenuItem.Text = "Chức vụ";
            chứcVụToolStripMenuItem.Click += chứcVụToolStripMenuItem_Click;
            // 
            // frmTrangChu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(892, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmTrangChu";
            Text = "frmTrangChu";
            Load += frmTrangChu_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem trangChủToolStripMenuItem;
        private ToolStripMenuItem nhânViênToolStripMenuItem;
        private ToolStripMenuItem phânToolStripMenuItem;
        private ToolStripMenuItem chấmCôngToolStripMenuItem;
        private ToolStripMenuItem lươngToolStripMenuItem;
        private ToolStripMenuItem ứngLươngToolStripMenuItem;
        private ToolStripMenuItem chứcVụToolStripMenuItem;
    }
}