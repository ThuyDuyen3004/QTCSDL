﻿namespace Nhom08
{
    public partial class frmTrangChu : Form
    {
        public frmTrangChu()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        //private void nhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    frmNhanVien nhanVien = new frmNhanVien();
        //    nhanVien.FormClosed += (s, args) => this.Show();  
        //    this.Hide();  
        //}
        private void nhânViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNhanVien nhanVien = new frmNhanVien();
            this.Hide(); 
            nhanVien.ShowDialog();  
            this.Show();  
        }


        private void phânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPhanCongCaLamViec phanCongCaLamViec = new frmPhanCongCaLamViec();
            phanCongCaLamViec.FormClosed += (s, args) => this.Show();  
            phanCongCaLamViec.Show();
            this.Hide();  
        }

        private void chấmCôngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChamCong chamCong = new frmChamCong();
            chamCong.FormClosed += (s, args) => this.Show();  
            chamCong.Show();
            this.Hide();  
        }

        private void lươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmLuong luong = new frmLuong();
            luong.FormClosed += (s, args) => this.Show();  
            luong.Show();
            this.Hide();  
        }

        private void ứngLươngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUngLuong ungLuong = new frmUngLuong();
            ungLuong.FormClosed += (s, args) => this.Show(); 
            ungLuong.Show();
            this.Hide();  
        }

        private void chứcVụToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmChucVu chucVu = new frmChucVu();
            chucVu.FormClosed += (s, args) => this.Show();
            chucVu.Show();
            this.Hide();

        }

        private void frmTrangChu_Load(object sender, EventArgs e)
        {

        }
    }
}
