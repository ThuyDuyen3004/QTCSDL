﻿namespace Nhom08
{
    partial class frmChamCong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textMaChamCong = new TextBox();
            label2 = new Label();
            textMaNhanVien = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            dateTimePickerNgayThangNam = new DateTimePicker();
            textSoPhutTre = new TextBox();
            textSoGioLam = new TextBox();
            textPhat = new TextBox();
            dateTimePickerGioDiLam = new DateTimePicker();
            dateTimePickerGioRaVe = new DateTimePicker();
            dataGridViewChamCong = new DataGridView();
            btnLuu = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewChamCong).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(16, 20);
            label1.Name = "label1";
            label1.Size = new Size(150, 25);
            label1.TabIndex = 0;
            label1.Text = "Mã chấm công";
            // 
            // textMaChamCong
            // 
            textMaChamCong.BorderStyle = BorderStyle.FixedSingle;
            textMaChamCong.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaChamCong.Location = new Point(198, 12);
            textMaChamCong.Name = "textMaChamCong";
            textMaChamCong.Size = new Size(171, 33);
            textMaChamCong.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(12, 73);
            label2.Name = "label2";
            label2.Size = new Size(142, 25);
            label2.TabIndex = 2;
            label2.Text = "Mã nhân viên";
            label2.Click += label2_Click;
            // 
            // textMaNhanVien
            // 
            textMaNhanVien.BorderStyle = BorderStyle.FixedSingle;
            textMaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaNhanVien.Location = new Point(198, 65);
            textMaNhanVien.Name = "textMaNhanVien";
            textMaNhanVien.Size = new Size(171, 33);
            textMaNhanVien.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(12, 128);
            label3.Name = "label3";
            label3.Size = new Size(166, 25);
            label3.TabIndex = 4;
            label3.Text = "Ngày tháng năm";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(421, 23);
            label4.Name = "label4";
            label4.Size = new Size(112, 25);
            label4.TabIndex = 5;
            label4.Text = "Giờ đi làm";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(421, 73);
            label5.Name = "label5";
            label5.Size = new Size(101, 25);
            label5.TabIndex = 6;
            label5.Text = "Giờ ra về";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(421, 128);
            label7.Name = "label7";
            label7.Size = new Size(111, 25);
            label7.TabIndex = 8;
            label7.Text = "Số giờ làm";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(778, 74);
            label8.Name = "label8";
            label8.Size = new Size(56, 25);
            label8.TabIndex = 9;
            label8.Text = "Phạt";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(778, 17);
            label9.Name = "label9";
            label9.Size = new Size(116, 25);
            label9.TabIndex = 10;
            label9.Text = "Số phút trễ";
            // 
            // dateTimePickerNgayThangNam
            // 
            dateTimePickerNgayThangNam.Format = DateTimePickerFormat.Short;
            dateTimePickerNgayThangNam.Location = new Point(198, 123);
            dateTimePickerNgayThangNam.Name = "dateTimePickerNgayThangNam";
            dateTimePickerNgayThangNam.Size = new Size(171, 31);
            dateTimePickerNgayThangNam.TabIndex = 11;
            // 
            // textSoPhutTre
            // 
            textSoPhutTre.BorderStyle = BorderStyle.FixedSingle;
            textSoPhutTre.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textSoPhutTre.Location = new Point(944, 12);
            textSoPhutTre.Name = "textSoPhutTre";
            textSoPhutTre.Size = new Size(171, 33);
            textSoPhutTre.TabIndex = 12;
            // 
            // textSoGioLam
            // 
            textSoGioLam.BorderStyle = BorderStyle.FixedSingle;
            textSoGioLam.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textSoGioLam.Location = new Point(577, 120);
            textSoGioLam.Name = "textSoGioLam";
            textSoGioLam.Size = new Size(171, 33);
            textSoGioLam.TabIndex = 13;
            // 
            // textPhat
            // 
            textPhat.BorderStyle = BorderStyle.FixedSingle;
            textPhat.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textPhat.Location = new Point(944, 68);
            textPhat.Name = "textPhat";
            textPhat.Size = new Size(171, 33);
            textPhat.TabIndex = 14;
            // 
            // dateTimePickerGioDiLam
            // 
            dateTimePickerGioDiLam.Format = DateTimePickerFormat.Time;
            dateTimePickerGioDiLam.Location = new Point(577, 12);
            dateTimePickerGioDiLam.Name = "dateTimePickerGioDiLam";
            dateTimePickerGioDiLam.Size = new Size(171, 31);
            dateTimePickerGioDiLam.TabIndex = 16;
            // 
            // dateTimePickerGioRaVe
            // 
            dateTimePickerGioRaVe.Format = DateTimePickerFormat.Time;
            dateTimePickerGioRaVe.Location = new Point(577, 68);
            dateTimePickerGioRaVe.Name = "dateTimePickerGioRaVe";
            dateTimePickerGioRaVe.Size = new Size(171, 31);
            dateTimePickerGioRaVe.TabIndex = 17;
            // 
            // dataGridViewChamCong
            // 
            dataGridViewChamCong.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewChamCong.Location = new Point(16, 193);
            dataGridViewChamCong.Name = "dataGridViewChamCong";
            dataGridViewChamCong.RowHeadersWidth = 62;
            dataGridViewChamCong.Size = new Size(1099, 235);
            dataGridViewChamCong.TabIndex = 18;
            dataGridViewChamCong.CellClick += dataGridViewChamCong_CellClick;
            dataGridViewChamCong.CellContentClick += dataGridViewChamCong_CellContentClick;
            // 
            // btnLuu
            // 
            btnLuu.BackColor = Color.Lime;
            btnLuu.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.Location = new Point(778, 123);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(97, 34);
            btnLuu.TabIndex = 19;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = false;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnSua
            // 
            btnSua.BackColor = Color.Yellow;
            btnSua.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.Location = new Point(896, 123);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(97, 34);
            btnSua.TabIndex = 20;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = false;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.BackColor = Color.Red;
            btnXoa.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(1014, 123);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(101, 34);
            btnXoa.TabIndex = 21;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // frmChamCong
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(1173, 450);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(dataGridViewChamCong);
            Controls.Add(dateTimePickerGioRaVe);
            Controls.Add(dateTimePickerGioDiLam);
            Controls.Add(textPhat);
            Controls.Add(textSoGioLam);
            Controls.Add(textSoPhutTre);
            Controls.Add(dateTimePickerNgayThangNam);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textMaNhanVien);
            Controls.Add(label2);
            Controls.Add(textMaChamCong);
            Controls.Add(label1);
            Name = "frmChamCong";
            Text = "frmChamCong";
            Load += frmChamCong_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewChamCong).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textMaChamCong;
        private Label label2;
        private TextBox textMaNhanVien;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label9;
        private DateTimePicker dateTimePickerNgayThangNam;
        private TextBox textSoPhutTre;
        private TextBox textSoGioLam;
        private TextBox textPhat;
        private DateTimePicker dateTimePickerGioDiLam;
        private DateTimePicker dateTimePickerGioRaVe;
        private DataGridView dataGridViewChamCong;
        private Button btnLuu;
        private Button btnSua;
        private Button btnXoa;
    }
}