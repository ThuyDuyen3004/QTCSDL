﻿namespace Nhom08
{
    partial class frmChucVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textMaChucVu = new TextBox();
            textChucVu = new TextBox();
            textLuongTheoGio = new TextBox();
            btnLuu = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            dataGridViewChucVu = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewChucVu).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(30, 34);
            label1.Name = "label1";
            label1.Size = new Size(124, 25);
            label1.TabIndex = 0;
            label1.Text = "Mã chức vụ";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(381, 42);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 1;
            label2.Text = "Chức vụ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(30, 92);
            label3.Name = "label3";
            label3.Size = new Size(156, 25);
            label3.TabIndex = 2;
            label3.Text = "Lương theo giờ";
            label3.Click += label3_Click;
            // 
            // textMaChucVu
            // 
            textMaChucVu.BorderStyle = BorderStyle.FixedSingle;
            textMaChucVu.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaChucVu.Location = new Point(196, 34);
            textMaChucVu.Name = "textMaChucVu";
            textMaChucVu.Size = new Size(150, 33);
            textMaChucVu.TabIndex = 3;
            // 
            // textChucVu
            // 
            textChucVu.BorderStyle = BorderStyle.FixedSingle;
            textChucVu.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textChucVu.Location = new Point(501, 32);
            textChucVu.Name = "textChucVu";
            textChucVu.Size = new Size(228, 33);
            textChucVu.TabIndex = 4;
            // 
            // textLuongTheoGio
            // 
            textLuongTheoGio.BorderStyle = BorderStyle.FixedSingle;
            textLuongTheoGio.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textLuongTheoGio.Location = new Point(196, 90);
            textLuongTheoGio.Name = "textLuongTheoGio";
            textLuongTheoGio.Size = new Size(150, 33);
            textLuongTheoGio.TabIndex = 5;
            // 
            // btnLuu
            // 
            btnLuu.BackColor = Color.Lime;
            btnLuu.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.ForeColor = SystemColors.ActiveCaptionText;
            btnLuu.Location = new Point(381, 90);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(105, 38);
            btnLuu.TabIndex = 6;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = false;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnSua
            // 
            btnSua.BackColor = Color.FromArgb(255, 255, 128);
            btnSua.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.Location = new Point(501, 90);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(105, 38);
            btnSua.TabIndex = 7;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = false;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.BackColor = Color.Red;
            btnXoa.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(624, 92);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(105, 38);
            btnXoa.TabIndex = 8;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // dataGridViewChucVu
            // 
            dataGridViewChucVu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewChucVu.Location = new Point(30, 172);
            dataGridViewChucVu.Name = "dataGridViewChucVu";
            dataGridViewChucVu.RowHeadersWidth = 62;
            dataGridViewChucVu.Size = new Size(699, 225);
            dataGridViewChucVu.TabIndex = 9;
            dataGridViewChucVu.CellClick += dataGridViewChucVu_CellClick;
            dataGridViewChucVu.CellContentClick += dataGridViewChucVu_CellContentClick;
            // 
            // frmChucVu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridViewChucVu);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(textLuongTheoGio);
            Controls.Add(textChucVu);
            Controls.Add(textMaChucVu);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmChucVu";
            Text = "frmChucVu";
            Load += frmChucVu_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewChucVu).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textMaChucVu;
        private TextBox textChucVu;
        private TextBox textLuongTheoGio;
        private Button btnLuu;
        private Button btnSua;
        private Button btnXoa;
        private DataGridView dataGridViewChucVu;
    }
}