﻿namespace Nhom08
{
    partial class frmLuong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textMaLuong = new TextBox();
            textMaNhanVien = new TextBox();
            textLuongCT = new TextBox();
            btnLuu = new Button();
            btnSua = new Button();
            btnXoa = new Button();
            dataGridViewLuong = new DataGridView();
            dateTimePickerThangNamLuong = new DateTimePicker();
            btnTinhLuong = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewLuong).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(21, 30);
            label1.Name = "label1";
            label1.Size = new Size(103, 25);
            label1.TabIndex = 0;
            label1.Text = "Mã lương";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(401, 30);
            label2.Name = "label2";
            label2.Size = new Size(142, 25);
            label2.TabIndex = 1;
            label2.Text = "Mã nhân viên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(21, 88);
            label3.Name = "label3";
            label3.Size = new Size(180, 25);
            label3.TabIndex = 2;
            label3.Text = "Tháng năm lương";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(401, 88);
            label4.Name = "label4";
            label4.Size = new Size(181, 25);
            label4.TabIndex = 3;
            label4.Text = "Lương chính thức";
            // 
            // textMaLuong
            // 
            textMaLuong.BorderStyle = BorderStyle.FixedSingle;
            textMaLuong.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaLuong.Location = new Point(209, 30);
            textMaLuong.Name = "textMaLuong";
            textMaLuong.Size = new Size(150, 33);
            textMaLuong.TabIndex = 4;
            // 
            // textMaNhanVien
            // 
            textMaNhanVien.BorderStyle = BorderStyle.FixedSingle;
            textMaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaNhanVien.Location = new Point(588, 22);
            textMaNhanVien.Name = "textMaNhanVien";
            textMaNhanVien.Size = new Size(150, 33);
            textMaNhanVien.TabIndex = 6;
            // 
            // textLuongCT
            // 
            textLuongCT.BorderStyle = BorderStyle.FixedSingle;
            textLuongCT.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textLuongCT.Location = new Point(588, 80);
            textLuongCT.Name = "textLuongCT";
            textLuongCT.Size = new Size(150, 33);
            textLuongCT.TabIndex = 7;
            // 
            // btnLuu
            // 
            btnLuu.BackColor = Color.Lime;
            btnLuu.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuu.Location = new Point(390, 138);
            btnLuu.Name = "btnLuu";
            btnLuu.Size = new Size(93, 31);
            btnLuu.TabIndex = 8;
            btnLuu.Text = "Lưu";
            btnLuu.UseVisualStyleBackColor = false;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnSua
            // 
            btnSua.BackColor = Color.Yellow;
            btnSua.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSua.Location = new Point(489, 138);
            btnSua.Name = "btnSua";
            btnSua.Size = new Size(93, 31);
            btnSua.TabIndex = 9;
            btnSua.Text = "Sửa";
            btnSua.UseVisualStyleBackColor = false;
            btnSua.Click += btnSua_Click;
            // 
            // btnXoa
            // 
            btnXoa.BackColor = Color.Red;
            btnXoa.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(599, 138);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(93, 31);
            btnXoa.TabIndex = 10;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // dataGridViewLuong
            // 
            dataGridViewLuong.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewLuong.Location = new Point(21, 213);
            dataGridViewLuong.Name = "dataGridViewLuong";
            dataGridViewLuong.RowHeadersWidth = 62;
            dataGridViewLuong.Size = new Size(717, 211);
            dataGridViewLuong.TabIndex = 11;
            dataGridViewLuong.CellClick += dataGridViewLuong_CellClick;
            dataGridViewLuong.CellContentClick += dataGridViewLuong_CellContentClick;
            // 
            // dateTimePickerThangNamLuong
            // 
            dateTimePickerThangNamLuong.CalendarFont = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePickerThangNamLuong.Format = DateTimePickerFormat.Short;
            dateTimePickerThangNamLuong.Location = new Point(207, 82);
            dateTimePickerThangNamLuong.Name = "dateTimePickerThangNamLuong";
            dateTimePickerThangNamLuong.Size = new Size(152, 31);
            dateTimePickerThangNamLuong.TabIndex = 12;
            // 
            // btnTinhLuong
            // 
            btnTinhLuong.BackColor = Color.FromArgb(255, 128, 0);
            btnTinhLuong.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTinhLuong.Location = new Point(209, 128);
            btnTinhLuong.Name = "btnTinhLuong";
            btnTinhLuong.Size = new Size(138, 41);
            btnTinhLuong.TabIndex = 13;
            btnTinhLuong.Text = "Tính lương";
            btnTinhLuong.UseVisualStyleBackColor = false;
            btnTinhLuong.Click += btnTinhLuong_Click;
            // 
            // frmLuong
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(800, 450);
            Controls.Add(btnTinhLuong);
            Controls.Add(dateTimePickerThangNamLuong);
            Controls.Add(dataGridViewLuong);
            Controls.Add(btnXoa);
            Controls.Add(btnSua);
            Controls.Add(btnLuu);
            Controls.Add(textLuongCT);
            Controls.Add(textMaNhanVien);
            Controls.Add(textMaLuong);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmLuong";
            Text = "frmLuong";
            Load += frmLuong_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewLuong).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textMaLuong;
        private TextBox textMaNhanVien;
        private TextBox textLuongCT;
        private Button btnLuu;
        private Button btnSua;
        private Button btnXoa;
        private DataGridView dataGridViewLuong;
        private DateTimePicker dateTimePickerThangNamLuong;
        private Button btnTinhLuong;
    }
}