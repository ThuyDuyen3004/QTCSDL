﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // buoc 0

namespace Nhom08
{
    public partial class frmChamCong : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";

        public frmChamCong()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void frmChamCong_Load(object sender, EventArgs e)
        {
            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from BangChamCong";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "BangChamCong");

            dataGridViewChamCong.DataSource = ds.Tables["BangChamCong"];

            con.Close(); //buoc 3

            textSoGioLam.ReadOnly = true;
            textSoPhutTre.ReadOnly = true;
            textPhat.ReadOnly = true;
        }

        private void dataGridViewChamCong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewChamCong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textMaChamCong.Text = dataGridViewChamCong.Rows[e.RowIndex].Cells["MaChamCong"].Value.ToString();
            textMaNhanVien.Text = dataGridViewChamCong.Rows[e.RowIndex].Cells["MaNV"].Value.ToString();
            dateTimePickerNgayThangNam.Value = Convert.ToDateTime(dataGridViewChamCong.Rows[e.RowIndex].Cells["NgayThangNam"].Value.ToString());
            dateTimePickerGioDiLam.Value = DateTime.Today + TimeSpan.Parse(dataGridViewChamCong.Rows[e.RowIndex].Cells["GioDiLam"].Value.ToString());
            dateTimePickerGioRaVe.Value = DateTime.Today + TimeSpan.Parse(dataGridViewChamCong.Rows[e.RowIndex].Cells["GioRaVe"].Value.ToString());
            textSoGioLam.Text = dataGridViewChamCong.Rows[e.RowIndex].Cells["SoGioLam"].Value.ToString();
            textSoPhutTre.Text = dataGridViewChamCong.Rows[e.RowIndex].Cells["SoPhutTre"].Value.ToString();
            textPhat.Text = dataGridViewChamCong.Rows[e.RowIndex].Cells["Phat"].Value.ToString();
            textMaChamCong.Enabled = false;
        }



        private void btnLuu_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                return;
            }

            
            string sMaChamCong = textMaChamCong.Text;
            string sMaNhanVien = textMaNhanVien.Text;
            string sNgayThangNam = dateTimePickerNgayThangNam.Value.ToString("yyyy-MM-dd");
            string sGioDiLam = dateTimePickerGioDiLam.Value.ToString("HH:mm:ss");
            string sGioRaVe = dateTimePickerGioRaVe.Value.ToString("HH:mm:ss");
            string sSoGioLam = textSoGioLam.Text;
            string sSoPhutTre = textSoPhutTre.Text;
            string sPhat = textPhat.Text;

            try
            {
                
                string sQuery = "insert into BangChamCong values (@MaChamCong, @MaNV, @NgayThangNam, @GioDiLam, @GioRaVe, @SoGioLam, @SoPhutTre, @Phat)";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaChamCong", sMaChamCong);
                cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
                cmd.Parameters.AddWithValue("@NgayThangNam", sNgayThangNam);
                cmd.Parameters.AddWithValue("@GioDiLam", sGioDiLam);
                cmd.Parameters.AddWithValue("@GioRaVe", sGioRaVe);
                cmd.Parameters.AddWithValue("@SoGioLam", sSoGioLam);
                cmd.Parameters.AddWithValue("@SoPhutTre", sSoPhutTre);
                cmd.Parameters.AddWithValue("@Phat", sPhat);

                cmd.ExecuteNonQuery();

               
                using (SqlCommand cmdTinhGio = new SqlCommand("TinhSoGioLamVaSoGioTre", con))
                {
                    cmdTinhGio.CommandType = CommandType.StoredProcedure;
                    cmdTinhGio.CommandTimeout = 60;

                    cmdTinhGio.ExecuteNonQuery();
                }

              
                string reloadQuery = "select * from BangChamCong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "BangChamCong");
                dataGridViewChamCong.DataSource = ds.Tables["BangChamCong"];

                MessageBox.Show("Thêm chấm công và cập nhật thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm dữ liệu: " + ex.Message, "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }




        private void btnSua_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu


            string sMaChamCong = textMaChamCong.Text;
            string sMaNhanVien = textMaNhanVien.Text;
            string sNgayThangNam = dateTimePickerNgayThangNam.Value.ToString("yyyy-MM-dd");
            string sGioDiLam = dateTimePickerGioDiLam.Value.ToString("HH:mm:ss");
            string sGioRaVe = dateTimePickerGioRaVe.Value.ToString("HH:mm:ss");
            string sSoGioLam = textSoGioLam.Text;
            string sSoPhutTre = textSoPhutTre.Text;
            string sPhat = textPhat.Text;



            string sQuery = "update BangChamCong set MaNV = @MaNV, " +
                "NgayThangNam = @NgayThangNam, GioDiLam = @GioDiLam, GioRaVe = @GioRaVe " +
                "where MaChamCong = @MaChamCong";


            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaChamCong", sMaChamCong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@NgayThangNam", sNgayThangNam);
            cmd.Parameters.AddWithValue("@GioDiLam", sGioDiLam);
            cmd.Parameters.AddWithValue("@GioRaVe", sGioRaVe);


            try
            {
                cmd.ExecuteNonQuery();

                using (SqlCommand cmdTinhGio = new SqlCommand("TinhSoGioLamVaSoGioTre", con))
                {
                    cmdTinhGio.CommandType = CommandType.StoredProcedure;
                    cmdTinhGio.ExecuteNonQuery();
                }

                MessageBox.Show("Cập nhật thành công!");

                string reloadQuery = "select * from BangChamCong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "BangChamCong");
                dataGridViewChamCong.DataSource = ds.Tables["BangChamCong"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật!", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }
                //buoc 2:
             
                string sMaChamCong = textMaChamCong.Text;
                string sQuery = "delete BangChamCong where MaChamCong = @MaChamCong";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaChamCong", sMaChamCong);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");

                    string reloadQuery = "select * from BangChamCong";
                    SqlDataAdapter da = new SqlDataAdapter(reloadQuery, sCon);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewChamCong.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa: " + ex.Message);
                }
                con.Close();
            }
        }
    }

}
