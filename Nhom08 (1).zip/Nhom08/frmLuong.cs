﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; //buoc 0

namespace Nhom08
{
    public partial class frmLuong : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";

        public frmLuong()
        {
            InitializeComponent();
        }

        private void frmLuong_Load(object sender, EventArgs e)
        {
            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from BangLuong";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "BangLuong");

            dataGridViewLuong.DataSource = ds.Tables["BangLuong"];

            con.Close(); //buoc 3
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                return;
            }


            string sMaNhanVien = textMaNhanVien.Text;
            string sMaLuong = textMaLuong.Text;
            string sThangNamLuong = dateTimePickerThangNamLuong.Value.ToString("yyyy-MM-dd");

            string sQuery = "insert into BangLuong (MaLuong, MaNV, ThangNamLuong) values (@MaLuong, @MaNV, @ThangNamLuong)";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaLuong", sMaLuong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@ThangNamLuong", sThangNamLuong);

            try
            {

                cmd.ExecuteNonQuery();
                SqlCommand cmdTinhLuong = new SqlCommand("TinhBangLuong", con);
                cmdTinhLuong.CommandType = CommandType.StoredProcedure;
                cmdTinhLuong.ExecuteNonQuery();

                MessageBox.Show("Thêm mới và tính lương thành công!", "Thông báo");

                string reloadQuery = "select * from BangLuong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "BangLuong");
                dataGridViewLuong.DataSource = ds.Tables["BangLuong"];
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi trong quá trình thêm mới: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }



        private void dataGridViewLuong_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewLuong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textMaLuong.Text = dataGridViewLuong.Rows[e.RowIndex].Cells["MaLuong"].Value.ToString();
            textMaNhanVien.Text = dataGridViewLuong.Rows[e.RowIndex].Cells["MaNV"].Value.ToString();
            dateTimePickerThangNamLuong.Value = Convert.ToDateTime(dataGridViewLuong.Rows[e.RowIndex].Cells["ThangNamLuong"].Value.ToString());
            textLuongCT.Text = dataGridViewLuong.Rows[e.RowIndex].Cells["LuongCT"].Value.ToString();

            textMaLuong.Enabled = false;
        }



        private void btnSua_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu
            string sMaNhanVien = textMaNhanVien.Text;
            string sMaLuong = textMaLuong.Text;
            string sLuongCT = textLuongCT.Text;
            string sThangNamLuong = dateTimePickerThangNamLuong.Value.ToString("yyyy-MM-dd");

            string sQuery = "update BangLuong set MaNV = @MaNV, ThangNamLuong = @ThangNamLuong,LuongCT = @LuongCT where MaLuong = @MaLuong";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaLuong", sMaLuong);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@ThangNamLuong", sThangNamLuong);
            cmd.Parameters.AddWithValue("@LuongCT", sLuongCT);
            try
            {
                cmd.ExecuteNonQuery(); // goi lenh update

                SqlCommand cmdTinhLuong = new SqlCommand("TinhBangLuong", con);
                cmdTinhLuong.CommandType = CommandType.StoredProcedure;
                cmdTinhLuong.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!");

                string reloadQuery = "select * from BangLuong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "BangLuong");
                dataGridViewLuong.DataSource = ds.Tables["BangLuong"];
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi trong quá trình cập nhật: {ex.Message}", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }
                //buoc 2:
                // lay gia tri
                string sMaLuong = textMaLuong.Text;
                string sQuery = "delete BangLuong where MaLuong = @MaLuong";
                SqlCommand cmd = new SqlCommand(sQuery, con);
                cmd.Parameters.AddWithValue("@MaLuong", sMaLuong);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa thành công!");

                    string reloadQuery = "select * from BangLuong";
                    SqlDataAdapter da = new SqlDataAdapter(reloadQuery, sCon);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridViewLuong.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa: " + ex.Message);
                }
                con.Close();
            }
        }

      
        private void btnTinhLuong_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(sCon);

            try
            {
                con.Open();

                
                SqlCommand cmdTinhLuong = new SqlCommand("TinhBangLuong", con);
                cmdTinhLuong.CommandType = CommandType.StoredProcedure;
                cmdTinhLuong.ExecuteNonQuery();

                string reloadQuery = "select * from BangLuong";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "BangLuong");
                dataGridViewLuong.DataSource = ds.Tables["BangLuong"];

                MessageBox.Show("Tính lương cho tất cả nhân viên thành công!", "Thông báo");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Xảy ra lỗi trong quá trình tính lương: {ex.Message}", "Thông báo");
            }
            finally
            {
                con.Close();
            }
        }
    }
}
