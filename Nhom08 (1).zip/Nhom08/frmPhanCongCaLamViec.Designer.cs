﻿namespace Nhom08
{
    partial class frmPhanCongCaLamViec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textMaPhanCong = new TextBox();
            label2 = new Label();
            textTenCaLam = new TextBox();
            label3 = new Label();
            dateTimePickerGioVaoCa = new DateTimePicker();
            label4 = new Label();
            textMaNhanVien = new TextBox();
            label5 = new Label();
            dateTimePickerNgayLam = new DateTimePicker();
            label6 = new Label();
            dateTimePickerGioKetCa = new DateTimePicker();
            btnLuuPhanCongCaLam = new Button();
            btnSuaPhanCongCaLam = new Button();
            btnXoaPhanCongCaLam = new Button();
            dataGridViewPhanCongCaLamViec = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPhanCongCaLamViec).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(59, 48);
            label1.Name = "label1";
            label1.Size = new Size(146, 25);
            label1.TabIndex = 0;
            label1.Text = "Mã phân công";
            // 
            // textMaPhanCong
            // 
            textMaPhanCong.BorderStyle = BorderStyle.FixedSingle;
            textMaPhanCong.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaPhanCong.Location = new Point(284, 40);
            textMaPhanCong.Name = "textMaPhanCong";
            textMaPhanCong.Size = new Size(150, 33);
            textMaPhanCong.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(63, 148);
            label2.Name = "label2";
            label2.Size = new Size(117, 25);
            label2.TabIndex = 2;
            label2.Text = "Tên ca làm";
            // 
            // textTenCaLam
            // 
            textTenCaLam.BorderStyle = BorderStyle.FixedSingle;
            textTenCaLam.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textTenCaLam.Location = new Point(284, 151);
            textTenCaLam.Name = "textTenCaLam";
            textTenCaLam.Size = new Size(150, 33);
            textTenCaLam.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(580, 100);
            label3.Name = "label3";
            label3.Size = new Size(114, 25);
            label3.TabIndex = 4;
            label3.Text = "Giờ vào ca";
            // 
            // dateTimePickerGioVaoCa
            // 
            dateTimePickerGioVaoCa.Format = DateTimePickerFormat.Time;
            dateTimePickerGioVaoCa.Location = new Point(737, 96);
            dateTimePickerGioVaoCa.Name = "dateTimePickerGioVaoCa";
            dateTimePickerGioVaoCa.Size = new Size(150, 31);
            dateTimePickerGioVaoCa.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(63, 100);
            label4.Name = "label4";
            label4.Size = new Size(142, 25);
            label4.TabIndex = 6;
            label4.Text = "Mã nhân viên";
            // 
            // textMaNhanVien
            // 
            textMaNhanVien.BorderStyle = BorderStyle.FixedSingle;
            textMaNhanVien.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textMaNhanVien.Location = new Point(284, 94);
            textMaNhanVien.Name = "textMaNhanVien";
            textMaNhanVien.Size = new Size(150, 33);
            textMaNhanVien.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(585, 46);
            label5.Name = "label5";
            label5.Size = new Size(101, 25);
            label5.TabIndex = 8;
            label5.Text = "Ngày làm";
            label5.Click += label5_Click;
            // 
            // dateTimePickerNgayLam
            // 
            dateTimePickerNgayLam.Font = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePickerNgayLam.Format = DateTimePickerFormat.Short;
            dateTimePickerNgayLam.Location = new Point(737, 40);
            dateTimePickerNgayLam.Name = "dateTimePickerNgayLam";
            dateTimePickerNgayLam.Size = new Size(150, 33);
            dateTimePickerNgayLam.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(585, 148);
            label6.Name = "label6";
            label6.Size = new Size(109, 25);
            label6.TabIndex = 10;
            label6.Text = "Giờ kết ca";
            // 
            // dateTimePickerGioKetCa
            // 
            dateTimePickerGioKetCa.CalendarFont = new Font("Times New Roman", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePickerGioKetCa.Format = DateTimePickerFormat.Time;
            dateTimePickerGioKetCa.Location = new Point(737, 151);
            dateTimePickerGioKetCa.Name = "dateTimePickerGioKetCa";
            dateTimePickerGioKetCa.Size = new Size(150, 31);
            dateTimePickerGioKetCa.TabIndex = 11;
            // 
            // btnLuuPhanCongCaLam
            // 
            btnLuuPhanCongCaLam.BackColor = Color.Lime;
            btnLuuPhanCongCaLam.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLuuPhanCongCaLam.Location = new Point(427, 200);
            btnLuuPhanCongCaLam.Name = "btnLuuPhanCongCaLam";
            btnLuuPhanCongCaLam.Size = new Size(78, 37);
            btnLuuPhanCongCaLam.TabIndex = 12;
            btnLuuPhanCongCaLam.Text = "Lưu";
            btnLuuPhanCongCaLam.UseVisualStyleBackColor = false;
            btnLuuPhanCongCaLam.Click += btnLuuPhanCongCaLam_Click;
            // 
            // btnSuaPhanCongCaLam
            // 
            btnSuaPhanCongCaLam.BackColor = Color.Yellow;
            btnSuaPhanCongCaLam.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSuaPhanCongCaLam.Location = new Point(545, 200);
            btnSuaPhanCongCaLam.Name = "btnSuaPhanCongCaLam";
            btnSuaPhanCongCaLam.Size = new Size(73, 37);
            btnSuaPhanCongCaLam.TabIndex = 13;
            btnSuaPhanCongCaLam.Text = "Sửa";
            btnSuaPhanCongCaLam.UseVisualStyleBackColor = false;
            btnSuaPhanCongCaLam.Click += btnSuaPhanCongCaLam_Click;
            // 
            // btnXoaPhanCongCaLam
            // 
            btnXoaPhanCongCaLam.BackColor = Color.Red;
            btnXoaPhanCongCaLam.Font = new Font("Times New Roman", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoaPhanCongCaLam.Location = new Point(644, 200);
            btnXoaPhanCongCaLam.Name = "btnXoaPhanCongCaLam";
            btnXoaPhanCongCaLam.Size = new Size(78, 37);
            btnXoaPhanCongCaLam.TabIndex = 14;
            btnXoaPhanCongCaLam.Text = "Xóa";
            btnXoaPhanCongCaLam.UseVisualStyleBackColor = false;
            btnXoaPhanCongCaLam.Click += btnXoaPhanCongCaLam_Click;
            // 
            // dataGridViewPhanCongCaLamViec
            // 
            dataGridViewPhanCongCaLamViec.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPhanCongCaLamViec.Location = new Point(41, 256);
            dataGridViewPhanCongCaLamViec.Name = "dataGridViewPhanCongCaLamViec";
            dataGridViewPhanCongCaLamViec.RowHeadersWidth = 62;
            dataGridViewPhanCongCaLamViec.Size = new Size(998, 259);
            dataGridViewPhanCongCaLamViec.TabIndex = 15;
            dataGridViewPhanCongCaLamViec.CellClick += dataGridViewPhanCongCaLamViec_CellClick;
            // 
            // frmPhanCongCaLamViec
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 234, 202);
            ClientSize = new Size(1068, 550);
            Controls.Add(dataGridViewPhanCongCaLamViec);
            Controls.Add(btnXoaPhanCongCaLam);
            Controls.Add(btnSuaPhanCongCaLam);
            Controls.Add(btnLuuPhanCongCaLam);
            Controls.Add(dateTimePickerGioKetCa);
            Controls.Add(label6);
            Controls.Add(dateTimePickerNgayLam);
            Controls.Add(label5);
            Controls.Add(textMaNhanVien);
            Controls.Add(label4);
            Controls.Add(dateTimePickerGioVaoCa);
            Controls.Add(label3);
            Controls.Add(textTenCaLam);
            Controls.Add(label2);
            Controls.Add(textMaPhanCong);
            Controls.Add(label1);
            Name = "frmPhanCongCaLamViec";
            Text = "frmPhanCongCaLamViec";
            Load += frmPhanCongCaLamViec_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewPhanCongCaLamViec).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textMaPhanCong;
        private Label label2;
        private TextBox textTenCaLam;
        private Label label3;
        private DateTimePicker dateTimePickerGioVaoCa;
        private Label label4;
        private TextBox textMaNhanVien;
        private Label label5;
        private DateTimePicker dateTimePickerNgayLam;
        private Label label6;
        private DateTimePicker dateTimePickerGioKetCa;
        private Button btnLuuPhanCongCaLam;
        private Button btnSuaPhanCongCaLam;
        private Button btnXoaPhanCongCaLam;
        private DataGridView dataGridViewPhanCongCaLamViec;
    }
}