﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; //buoc 0

namespace Nhom08
{
    public partial class frmNhanVien : Form
    {
        string sCon = "Data Source=LAPTOP-L6V0NQIN\\THANHTUYET;Initial Catalog=QuanLyNhanSu;Integrated Security=True;Trust Server Certificate=True";
        public frmNhanVien()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textSoDienThoai_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmNhanVien_Load(object sender, EventArgs e)
        {
            // bước 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }
            //bước 2
            string sQuery = "select * from NhanVien";

            SqlDataAdapter adapter = new SqlDataAdapter(sQuery, con);

            DataSet ds = new DataSet();

            adapter.Fill(ds, "NhanVien");

            dataGridViewNhanVien.DataSource = ds.Tables["NhanVien"];

            con.Close(); //buoc 3




        }

        private void btnLuuNhanVien_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaNhanVien = textMaNhanVien.Text;
            string sHoTen = textHoVaTen.Text;
            string sNgaySinh = dateTimePickerNgaysinh.Value.ToString("yyyy-MM-dd");
            string sMaChucVu = textMaChucVu.Text;
            string sDiaChi = textDiaChi.Text;
            string sSoDienThoai = textSoDienThoai.Text;
            int iGioiTinh = 0;
            if (btnrbNam.Checked == true)
            {
                iGioiTinh = 1;
            }

            // kiem tra tinh hop le cua du lieu

            // Kiểm tra Mã nhân viên
            if (string.IsNullOrWhiteSpace(sMaNhanVien) || sMaNhanVien.Length != 7)
            {
                MessageBox.Show("Mã nhân viên phải có 7 ký tự và không được để trống.", "Thông báo");
                return;
            }

            string checkMaNVQuery = "SELECT COUNT(*) FROM NhanVien WHERE MaNV = @MaNV";
            SqlCommand checkMaNVCmd = new SqlCommand(checkMaNVQuery, con);
            checkMaNVCmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            if ((int)checkMaNVCmd.ExecuteScalar() > 0)
            {
                MessageBox.Show("Mã nhân viên đã tồn tại.", "Thông báo");
                return;
            }

          

            // Kiểm tra Số điện thoại
       
            if (string.IsNullOrWhiteSpace(sSoDienThoai))
            {
                MessageBox.Show("Số điện thoại không được để trống.", "Thông báo");
                return;
            }



            // Kiểm tra Giới tính
            if (!btnrbNam.Checked && !btnrbNu.Checked)
            {
                MessageBox.Show("Vui lòng chọn giới tính.", "Thông báo");
                return;
            }

            // Kiểm tra Địa chỉ
            if (!string.IsNullOrWhiteSpace(sDiaChi) && sDiaChi.Length > 150)
            {
                MessageBox.Show("Địa chỉ không được vượt quá 150 ký tự.", "Thông báo");
                return;
            }

            // Kiểm tra Ngày sinh
            if (dateTimePickerNgaysinh.Value >= DateTime.Now)
            {
                MessageBox.Show("Ngày sinh không hợp lệ. Vui lòng chọn ngày nhỏ hơn ngày hiện tại.", "Thông báo");
                return;
            }

          

            string checkMaChucVuQuery = "select count (*) from ChucVu where MaChucVu = @MaChucVu";
            SqlCommand checkMaChucVuCmd = new SqlCommand(checkMaChucVuQuery, con);
            checkMaChucVuCmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);

            if ((int)checkMaChucVuCmd.ExecuteScalar() == 0)
            {
                MessageBox.Show("Mã chức vụ không tồn tại.", "Thông báo");
                return;
            }

            string sQuery = "insert into NhanVien values (@MaNV, @Hovaten, @Sodienthoai, @Gioitinh, @Diachi, @Ngaythangnamsinh, @MaChucVu) ";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@Hovaten", sHoTen);
            cmd.Parameters.AddWithValue("@Sodienthoai", (object)sSoDienThoai ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Gioitinh", iGioiTinh);
            cmd.Parameters.AddWithValue("@Diachi", (object)sDiaChi ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Ngaythangnamsinh", sNgaySinh);
            cmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);

            try
            {
                cmd.ExecuteNonQuery();

                MessageBox.Show("Thêm mới thành công!");
                string reloadQuery = "select * from NhanVien";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "NhanVien");
                dataGridViewNhanVien.DataSource = ds.Tables["NhanVien"];
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Xảy ra lỗi trong quá tình thêm mới!");
                MessageBox.Show("Xảy ra lỗi trong quá trình thêm mới!", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();




        }

        private void dataGridViewNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textMaNhanVien.Text = dataGridViewNhanVien.Rows[e.RowIndex].Cells["MaNV"].Value.ToString();
            textMaChucVu.Text = dataGridViewNhanVien.Rows[e.RowIndex].Cells["MaChucVu"].Value.ToString();
            textHoVaTen.Text = dataGridViewNhanVien.Rows[e.RowIndex].Cells["Hovaten"].Value.ToString();
            int iGioiTinh = Convert.ToUInt16(dataGridViewNhanVien.Rows[e.RowIndex].Cells["Gioitinh"].Value);
            dateTimePickerNgaysinh.Value = Convert.ToDateTime(dataGridViewNhanVien.Rows[e.RowIndex].Cells["Ngaythangnamsinh"].Value);
            textSoDienThoai.Text = dataGridViewNhanVien.Rows[e.RowIndex].Cells["Sodienthoai"].Value.ToString();
            textDiaChi.Text = dataGridViewNhanVien.Rows[e.RowIndex].Cells["Diachi"].Value.ToString();

            if (iGioiTinh == 1)
            {
                btnrbNam.Checked = true;
            }
            else
            {
                btnrbNu.Checked = true;
            }

            textMaNhanVien.Enabled = false;
        }

        private void btnSuaNhanVIen_Click(object sender, EventArgs e)
        {
            // buoc 1
            SqlConnection con = new SqlConnection(sCon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
            }

            // buoc 2: chuan bi du lieu

            // gan du lieu

            string sMaNhanVien = textMaNhanVien.Text;
            string sHoTen = textHoVaTen.Text;
            string sNgaySinh = dateTimePickerNgaysinh.Value.ToString("yyyy-MM-dd");
            string sMaChucVu = textMaChucVu.Text;
            string sDiaChi = textDiaChi.Text;
            string sSoDienThoai = textSoDienThoai.Text;
            int iGioiTinh = 0;
            if (btnrbNam.Checked == true)
            {
                iGioiTinh = 1;
            }


            string checkMaChucVuQuery = "select count (*) from ChucVu where MaChucVu = @MaChucVu";
            SqlCommand checkMaChucVuCmd = new SqlCommand(checkMaChucVuQuery, con);
            checkMaChucVuCmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);
            if ((int)checkMaChucVuCmd.ExecuteScalar() == 0)
            {
                MessageBox.Show("Mã chức vụ không tồn tại.", "Thông báo");
                return;
            }


            string sQuery = "update NhanVien set Hovaten = @Hovaten, MaChucVu = @MaChucVu, Diachi = @Diachi, Sodienthoai = @Sodienthoai," + " Ngaythangnamsinh = @Ngaythangnamsinh, Gioitinh = @Gioitinh " + "where MaNV = @MaNV";
            SqlCommand cmd = new SqlCommand(sQuery, con);
            cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);
            cmd.Parameters.AddWithValue("@Hovaten", sHoTen);
            cmd.Parameters.AddWithValue("@Sodienthoai", (object)sSoDienThoai ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Gioitinh", iGioiTinh);
            cmd.Parameters.AddWithValue("@Diachi", (object)sDiaChi ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@Ngaythangnamsinh", sNgaySinh);
            cmd.Parameters.AddWithValue("@MaChucVu", sMaChucVu);

            try
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật thành công!");

                string reloadQuery = "select * from NhanVien";
                SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "NhanVien");
                dataGridViewNhanVien.DataSource = ds.Tables["NhanVien"];
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("Xảy ra lỗi trong quá trình cập nhật! ", "Thông báo");

            }

            //buoc 3: dong ket noi
            con.Close();

        }

        private void btnXoaNhanVien_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel);
            if (ret == DialogResult.OK)
            {
                // buoc 1
                SqlConnection con = new SqlConnection(sCon);
                try
                {
                    con.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình kết nối Database", "Thông báo");
                }

                // buoc 2: chuẩn bị dữ liệu
                string sMaNhanVien = textMaNhanVien.Text;

                // Gọi thủ tục xóa nhân viên
                SqlCommand cmd = new SqlCommand("XoaThongTinNV", con);
                cmd.CommandType = CommandType.StoredProcedure;

                // Thêm tham số cho thủ tục
                cmd.Parameters.AddWithValue("@MaNV", sMaNhanVien);

                SqlParameter refParam = new SqlParameter("@ref", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(refParam);

                try
                {
                    cmd.ExecuteNonQuery();

                    bool isDeleted = (bool)refParam.Value;
                    if (isDeleted)
                    {
                        MessageBox.Show("Xóa thành công!");
                        string reloadQuery = "select * from NhanVien";
                        SqlDataAdapter adapter = new SqlDataAdapter(reloadQuery, con);
                        DataSet ds = new DataSet();
                        adapter.Fill(ds, "NhanVien");
                        dataGridViewNhanVien.DataSource = ds.Tables["NhanVien"];
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy nhân viên hoặc không có dữ liệu cần xóa.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Xảy ra lỗi trong quá trình xóa! ", "Thông báo");
                }

                // Bước 3: Đóng kết nối
                con.Close();
            }

        }

        private void textMaNhanVien_TextChanged(object sender, EventArgs e)
        {

        }

        private void MaNV_Click(object sender, EventArgs e)
        {

        }
    }
}
